package Docenten;

import java.util.Scanner;

/**
 * DocentenVoorbeeld : TestVanDocenten2
 *
 * @author katja.verbeeck
 * @version 13/01/2021
 */
public class TestVanDocenten2 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("Hoeveel docentennamen wil je ingeven ?");
        int aantal = scan.nextInt();
        Docenten2 ict = new Docenten2(aantal);

        //inlezen namen en toevoegen
        for (int i = 0; i < aantal; i++) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Voornaam: ");
            String voornaam = sc.next();
            sc.nextLine();
            System.out.print("Familienaam: ");
            String naam = sc.nextLine();
            ict.voegDocentToe(voornaam, naam);
        }
        // teruggeven initialen
        System.out.println("Dit zijn de initialen van de docenten : ");
        for(int i = 0; i < aantal; i++){
            System.out.println(ict.geefInitialen(i));
        }
    }
}
