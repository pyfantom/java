package Docenten;

/**
 * DocentenVoorbeeld : Docenten2
 *
 * @author katja.verbeeck
 * @version 13/01/2021
 */
public class Docenten2 {

    String[][] docenten;


    /** betere versie, de initialisatie gebeurt nu via de constructor !
     * @param aantal
     */
    public Docenten2(int aantal) {
        docenten = new String[aantal][2];
    }

    /**
     * @param voornaam
     * @param naam
     * @return toegevoegen is gelukt of niet
     */
    public boolean voegDocentToe(String voornaam, String naam){
        for(int rij = 0; rij < docenten.length ; rij++){
            if(docenten[rij][0] == null){
                docenten[rij][0] = voornaam;
                docenten[rij][1] = naam;
                return true;
            }
        }
        return false;
    }

    /**
     * @return initialen :  geef de initialen van de persoon op plaats idx in de rij
     */
    public String geefInitialen(int idx){
        String initialen = "";
        if(! (docenten == null)){
            if(idx >= 0 && idx < docenten.length){

                String vnaam = docenten[idx][0];
                String famNaam = docenten[idx][1];

                initialen = "" + vnaam.charAt(0);
                int i = famNaam.indexOf(' ');
                while( i != -1){
                    initialen += " " + famNaam.charAt(0);
                    famNaam = famNaam.substring(i + 1);
                    i = famNaam.indexOf(' ');
                }
                initialen += " " + famNaam.charAt(0);
            }
        }
        return initialen;
    }


}